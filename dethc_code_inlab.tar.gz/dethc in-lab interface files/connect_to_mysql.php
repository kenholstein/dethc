<?php

$db_host = "localhost";

$db_username = "emptyfi1_flash";

$db_pass = "kemplab";

$db_name = "emptyfi1_detHC";

?>
