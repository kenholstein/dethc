<span></span>
<script>
function hideShow()
{
inst = document.getElementById('inst');
if (inst.style.display=='none')
{
  inst.style.display = 'block';
  theader2.style.display = 'block';
  theader1.style.display = 'none';
}
else
{
  inst.style.display = 'none';
  theader1.style.display = 'block';
  theader2.style.display = 'none';
}
}
</script>


<center><br />
<input id="but1" value="Click to switch between the interface and instructions" onclick="hideShow();" type="button" /></center>
<center><p id="theader1" style="display: block"><b>Interactive Interface</b></p>
<p id="theader2" style="display: none"><b>Instructions</b></p></center>
<div id="inst" style="display: none">
<center>
<iframe src="instructions.html" allowfullscreen="" iframe="" width="640" frameborder="0" height="700"></iframe></center><br />
<br /></div>
<div id="interface">
<center><embed src="https://googledrive.com/host/0B1YIsbitN_hjQWcwdDNLRXdSbWM/dethc.swf" type="application/x-shockwave-flash" flashvars="user_id=<?php echo $_GET["user_id"] ?>&purple_percent=<?php echo $_GET["purple_percent"] ?>&yellow_percent=<?php echo $_GET["yellow_percent"] ?>" width="600" height="700"></center></div>